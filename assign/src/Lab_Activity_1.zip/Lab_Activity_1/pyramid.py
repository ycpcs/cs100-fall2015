__author__ = 'djhake2'
# Load TurtleWorld functions
from TurtleWorld import *
from math import *

# Function to have turtle 't' draw a square of size 'x' CCW
def square(t,x):
    pd(t)
    i = 4
    while i > 0:
        fd(t,x)
        lt(t,90)
        i = i - 1
    pu(t)


# Function to have turtle 't' draw a row of 4 blocks (squares) of a fixed size (20)
def row_fixed_size_fixed_num(t):
    i = 4
    while i > 0:
        square(t, 20)
        fd(t,20)
        i = i - 1
    bk(t, 4*20)


# Function to have turtle 't' draw a row of 'numBlocks' blocks (squares) of a fixed size (20)
def row_fixed_size_var_num(t, numBlocks):
    # TODO: Modify to use numBlocks for the number of blocks in the row
    i = 4
    while i > 0:
        square(t, 20)
        fd(t,20)
        i = i - 1
    bk(t, 4*20)


# Function to have turtle 't' draw a row of 'numBlocks' blocks (squares) of size 'blockSize'
def row(t, numBlocks, blockSize):
    # TODO: Modify to use numBlocks for the number of blocks in the row
    #      and blockSize for the size of each block in the row (use the size multiplier of 20)
    i = 4
    while i > 0:
        square(t, 20)
        fd(t,20)
        i = i - 1
    bk(t, 4*20)


# Function to have turtle 't' draw a pyramid of 'height' rows using blocks (squares) of fixed size
#   Note: the height determines the number of blocks in the base row
def pyramid_fixed_block_size(t, height):
    i = height
    while i > 0:
        # TODO: Modify repeated code to draw the rows and reposition the cursor here
        row(t,height,1)
        lt(t,90)
        fd(t, 1*20)
        rt(t,90)
        i = i - 1

    # TODO: Modify to reposition the cursor to the lower left facing right
    rt(t,90)
    fd(t,height*20)
    lt(t,90)


# Function to have turtle 't' draw a pyramid of 'height' rows using blocks (squares) with size relative to the
# number of blocks in each row
#   Note: the height determines the number of blocks in the base row
#         when repositioning you will need to use the size multiplier of 20 in your calculations
def pyramid(t, height):
    i = height
    while i > 0:
        # TODO: Modify repeated code to draw the rows and reposition the cursor here
        row(t,height,1)
        lt(t,90)
        fd(t, 1*20)
        rt(t,90)
        i = i - 1

    # TODO: Modify to reposition the cursor to the lower left facing right
    rt(t,90)
    fd(t,height*20)
    lt(t,90)


def main():
    # Create TurtleWorld object
    world = TurtleWorld()
    # Create Turtle object
    t = Turtle()
    t.delay = 0.001

    # Draw row of fixed block size and fixed number of blocks
    world.clear()
    row_fixed_size_fixed_num(t)
    key = input('Press any key to run the next test')

    # Draw row of fixed block size and variable number of blocks
    world.clear()
    row_fixed_size_var_num(t, 5)
    key = input('Press any key to run the next test')

    # Draw row of variable block size and variable number of blocks
    world.clear()
    row(t, 6, 10)
    key = input('Press any key to run the next test')

    # Draw pyramid using fixed size blocks with 5 blocks in the base row
    world.clear()
    pyramid_fixed_block_size(t,5)
    key = input('Press any key to run the next test')

    # Draw pyramid using relative size blocks with 5 blocks in the base row
    world.clear()
    pyramid(t,5)
    key = input('Press any key to run the next test')

    # Press enter to exit
    key = input('Press enter to exit')
    world.destroy()

main()