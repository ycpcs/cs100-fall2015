__author__ = 'djhake2'
# Load TurtleWorld functions
from TurtleWorld import *
from math import *

scale = 10

# Function to have turtle 't' draw a square of size 'x' CCW
def square(t,x):
    pd(t)
    i = 4
    while i > 0:
        fd(t,x)
        lt(t,90)
        i = i - 1
    pu(t)


# Function to have turtle 't' draw a row of 'numBlocks' blocks (squares) of size 'blockSize'
def row(turtle, numBlocks, blockSize):
    i = num
    while i > 1:
        draw_square(t, blockSize*scale)
        fd(blockSize*scale)
    bk(t, num * blocksize*scale)

# Function to have turtle 't' draw a pyramid of 'height' rows using blocks (squares) with size relative to the
# number of blocks in each row
#   Note: the height determines the number of blocks in the base row
#         when repositioning you will need to use the size multiplier of 5 in your calculations
def pyramid(t, height):
    i = height
    while i > 0:
        row(t,i,i)
        lt(t,90)
        fd(t,i * scale)
        rt(t,90)
        fd(t, height * scale)
        i = i - 1

    rt(t,90)
    fd(t,(height/ 2) * scale)
    lt(t,90)
    bk(t,(width / 2) * scale)


def main():
    # Create TurtleWorld object
    world = TurtleWorld()
    # Create Turtle object
    turtle = Turtle()
    turtle.delay = 0.001

    # Draw row of variable block size and variable number of blocks
    world.clear()
    num = int(input('Enter the number of blocks in the row: '))
    len = input('Enter the size of the blocks: ')
    draw_row(turlte, num, len)
    key = input('Press any key to run the next test')

    # Draw pyramid using relative size blocks with variable number of blocks in the base row
    world.destroy()
    num = int(input('Enter the height of the pyramid: '))
    draw_pyramid(turtle,num)

    # Press enter to exit
    key = input('Press enter to exit')
    world.destroy()

main()