__author__ = 'Don'

print('\n\n   Problem 1 Solution')
print('*****************************')

# TODO: Run with debugger to determine values
#       of i and sum at the end of each iteration
num = 5
sum = 0

for i in range (num):
    i = 2*(i+1) - 1
    sum = sum + i

print('\n\n   Problem 2 Solution')
print('*****************************\n')

a = int(input('Enter quadratic coefficient: '))
b = int(input('Enter linear coefficient: '))
c = int(input("Enter constant coefficient: "))

n = int(input('Enter maximum evaluation value: '))

# TODO: Enter your code here
