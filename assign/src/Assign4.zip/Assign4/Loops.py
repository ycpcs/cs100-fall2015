__author__ = 'djhake2'
# Load TurtleWorld functions
from TurtleWorld import *
from math import *

bar_width = 4
scale = 0.02

# reposition cursor (negative is backwards)
def move_turtle(t, horizontal, vertical):
    pu(t)
    fd(t, horizontal)
    lt(t, 90)
    fd(t, vertical)
    rt(t,90)

# Function to have turtle 't' draw a vertical bar CCW of a fixed width (bar_width) and with height (height * scale)
# TODO: define a function named 'draw_bar' that accepts a turtle 't', and 'height', and draws a vertical bar
#       bar-width wide and height * scale high in a CCW direction, and then leaves the cursor in the lower right corner
#       of the bar facing right.  Rather than repeat the code twice, use a loop to draw the two halves of the bar.


# Function to have turtle 't' draw a spiral arm of length (length * scale), turning left after the line segment is drawn
# TODO: define a function named draw_spiral_arm that accetps a turtle 't' and 'length', and draws a line of length * scale
# and then turns left 90 degrees


def main():
    # Create TurtleWorld object
    world = TurtleWorld()

    # Create Turtle objects
    t1 = Turtle()   # linear bar graph
    t2 = Turtle()   # linear spiral
    t3 = Turtle()   # x^2 bar graph
    t4 = Turtle()   # x^2 spiral
    t5 = Turtle()   # Fibonacci bar graph
    t6 = Turtle()   # Fibonacci spiral
    t7 = Turtle()   # Factorial bar graph
    t8 = Turtle()   # Factorial spiral

    # set draw rates for each turtle
    t1.delay = 0.02
    t2.delay = 0.02
    t3.delay = 0.02
    t4.delay = 0.02
    t5.delay = 0.02
    t6.delay = 0.02
    t7.delay = 0.02
    t8.delay = 0.02

    # get number of values to use for loops
    num = int(input('Enter the # of values to use in each loop: '))
    world.clear()

    # position cursor near lower left corner before drawing bar graph
    move_turtle(t1,-190,-190)

    # Draw a linear bar graph for the specified number of values using turtle t1
    # EXAMPLE: using a loop and the draw_bar function to draw a linear bar graph from 0 to num - 1
    # the supplied print statement within the loop outputs the values to the Python console as the graph is drawn
    # 100 is used as an additional scale factor to give a reasonable sense of scale to the linear bar graph
    for i in range(num):
        draw_bar(t1,i * 100)

        # print the value
        print('i: ', i)

    key = input('Press any key to draw a spiral using linear values')
    world.clear()

    # Draw a linear spiral using the specified number of values using turtle t2
    # EXAMPLE: using a loop and the draw_spiral_arm function to draw a linear spiral from 0 to num - 1
    # the supplied print statement within the loop outputs the values to the Python console as the graph is drawn
    # 100 is used as an additional scale factor to give a reasonable sense of scale to the linear  spiral
    for i in range(num):
       draw_spiral_arm(t2,i * 100)

       # print the value
       print('i: ', i)

    key = input('Press any key to draw a bar graph using squared values')
    world.clear()

    # position cursor near lower left corner
    move_turtle(t3, -190,-190)

    # Draw a bar graph using the specified number of squared values using turtle t3
    # TODO: use a loop and the draw_bar function to draw a bar graph of the squares of the values 0 to num-1
    # use the supplied print statement in the loop to output the values to the console as the bar graph is drawn

    # print the value
    print('i: ', i, ' i^2: ', i*i)

    key = input('Press any key to draw a spiral using squared values')
    world.clear()

    # Draw a spiral using the specified number of squared values using turtle t4
    # TODO: use a loop and the draw_spiral_arm function to draw a spiral of the squares of the values from 0 to num-1
    # use the supplied print statement in the loop to output the values to the console as the bar graph is drawn

    # print the value
    print('i: ', i, ' i^2: ', i*i)

    key = input('Press any key to draw a bar graph using Fibonacci series values')
    world.clear()

    # position cursor near lower left corner
    move_turtle(t5,-190,-190)

    # initialize Fibonacci series variables
    sum1 = 0
    sum2 = 1

   # Draw a bar graph using the specified number of Fibonacci series terms using turtle t5
    # TODO: use a loop and the draw_bar function to draw a bar graph of the Fibonacci series terms from 0 to num-1
    #       you will want to use the variables initialized above inside the loop to store the two terms required to
    #       calculate the next entry in the Fibonacci sequence
    # use the supplied print statement in the loop to output the values to the console as the bar graph is drawn

    # print the value
    print('i: ', i, ' Fib: ', sum2)


    key = input('Press any key to draw a spiral using Fibonacci series values')
    world.clear()

    # initialize Fibonacci series variables
    sum1 = 0
    sum2 = 1

    # Draw a spiral using the specified number of Fibonacci series entries using turtle t6
    # TODO: use a loop and the draw_spiral_arm function to draw a spiral of the Fibonacci series terms from 0 to num-1
    #       again use the variables initialized above  inside the loop to store the two terms required to
    #       calculate the next entry in the Fibonacci sequence
    # use the supplied print statement in the loop to output the values to the console as the bar graph is drawn

    # print the value
    print('i: ', i, ' Fib: ', sum2)


    key = input('Press any key to draw a bar graph using Factorial values')
    world.clear()

    # position cursor near lower left corner
    move_turtle(t7,-190,-190)

    # initialize Factorial variable
    factorial = 1

    # Draw a bar graph using the specified number of Factorial entries using turtle 7
    # TODO: use a loop and the draw_bar function to draw a bar graph of the Factorial terms from 1 to num-1
    #       use the variable initialize above inside the loop to accumulate the Factorial product
    # use the supplied print statement in the loop to output the values to the console as the bar graph is drawn

    # print the value
    print('i: ', i, ' i!: ', factorial)


    key = input('Press any key to draw a spiral using Factorial values')
    world.clear()

    # initialize Factorial variable
    factorial = 1

    # Draw a spiral using the specified number of Factorial entries using turtle 8
    # TODO: use a loop and the draw_sprial_arm function to draw a spiral of the Factorial terms from 1 to num-1
    #       use the variable initialize above inside the loop to accumulate the Factorial product
    # use the supplied print statement in the loop to output the values to the console as the bar graph is drawn

    # print the value
    print('i: ', i, ' i!: ', factorial)


    # Press enter to exit
    key = input('Press enter to exit')
    world.destroy()

main()