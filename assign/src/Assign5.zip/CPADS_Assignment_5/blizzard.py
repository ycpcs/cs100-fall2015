from math import *
from random import *
from TurtleWorld import *

# comp_pi approximates pi by generating random points and then checking whether those points fall within a circle
# of radius 1.  thresh specifies the minimum difference between pi and the approximate value of pi being calculated for
# which the while loop should continue to run.
def comp_pi(thresh):
    # TODO (0): supply appropriate initial values for the following variables and then use those variables in the loop
    # NOTE: The given values are not correct
    approx_pi  = -1000
    num_points = -1000
    num_in     = -1000

    # TODO (1): Replace 'False" with the condition for the while loop so that it runs while the current estimate for PI
    #          differs from the actual value for PI by more than the user supplied threshold (thresh)
    while (False):
       x = random()     # this gets a random value for 'x'
       y = random()     # this gets a random value for 'y'

       # TODO (2): Count the number of random points (num_points) generated

       # TODO (3): Supply the calculation for the distance (dist) between point (x,y) and the origin

       # TODO (4): Keep count of the points (num_in) that fall within the circle (dist <= 1)

       # TODO (5): Calculate the new approximation of PI (approx_pi = 4 x (points in circle / total points)


    print("pi =        ", pi)
    print("approx pi = ", approx_pi)
    print("delta =     ", pi - approx_pi)
    print("points =    ", num_points)
    print("")
    return num_points


def draw_Koch(t,length):
	# TODO: Complete Koch function
    fd(t,length)

# Function to draw a snowflake
def draw_snowflake(t,size):
	# TODO: Draw a snowflake by making Koch curves in a triangle
    pd(t)
    draw_Koch(t,size)

# Function to draw blizzard
def draw_blizzard(t,size,num_top,num_bottom):
	#TODO: Draw all snowflakes
    x = randint(-100,100)
    y = randint(-100,100)
    move_turtle_no_draw(t,x,y)
    point_turtle(t,0)
    draw_snowflake(t,size)

# move turtle to new coordinates
# does not change pen status (up/down)
# does not change pen color
# if pen is already down, draws a line using current color
# if pen is already up, does not draw
def move_turtle(t,x,y):

    # get the current turtle coordinates (x0,y0)
    x0 = t.get_x()
    y0 = t.get_y()

    # calculate distance to new location (x,y) from current location (x0,, y0)
    # Pythagorean theorem
    distance = sqrt(pow(x - x0, 2) + pow(y - y0, 2))

    # calculate the new turtle heading, based on difference in coordinates
    # recall that arctangent returns the angle for a given tangent value
    # and that tangent = rise / run
    # use Python atan2(x,y) function, which returns the new absolute heading in radians (+ pi to -pi)
    # you'll need to convert heading from radians to degrees (try Google)
    heading = atan2(y - y0, x - x0) * 360/(2*pi)

    # set the new turtle heading, relative to the current heading
    # use left turn (lt), which is in the positive direction
    point_turtle(t,heading)

    # move the turtle to the new coordinates
    fd(t,distance)


# move turtle to new coordinates without drawing
def move_turtle_no_draw(t,x,y):

    # pick up pen
    pu(t)

    # move turtle (does not draw)
    move_turtle(t,x,y)


# move turtle to new coordinates while drawing with "color"
def move_turtle_draw(t, x, y, color):

    # put pen down
    pd(t)
    t.set_pen_color(color)

    # move turtle, drawing with the specified color
    move_turtle(t,x,y)

    # pick pen up
    pu(t)

def point_turtle(t,heading):
    heading0 = t.get_heading()
    lt(t,heading-heading0)

def main():
    seed()

    print("1 - Approximate Pi")
    print("2 - Draw Blizzard")
    menu = int(input("Select 1 or 2: "))

    if 1 == menu:
        # TODO (6): embed the following input line in a 'while' loop so that the user is required to enter a value
        #           for 'digits' that falls within the range specified by the prompt.
        digits = int(input("Enter number of digits for pi (3 to 10 digits): "))

        epsilon = 10**(-1*digits)

        # TODO (7): embed the following input line in a 'while' loop so that the user is required to enter a value
        #           for 'runs' that falls within the range specified by the prompt.
        runs = int(input("Enter number of comp_pi runs to average (1 to 10): "))

        # this loop runs comp_pi for the specified number of times, and then averages the counts
        # across all runs of comp_pi
        sum = 0
        for i in range(runs):
            num = comp_pi(epsilon)
            sum = sum + num

        avg = sum/runs

        print ("Average number of points for epsilon = ", epsilon, " is ", avg)

    elif 2 == menu:
        world = TurtleWorld()
        turtle = Turtle()
        turtle.delay = 0.00000000001

		# TODO: Validate size
        size = int(input("Enter a snowflake size greater than 10: "))

        # TODO: Validate num_top
        num_top = int(input("Enter between 0-10 snowflakes for the top: "))

		# TODO: Validate num_bottom
        num_bottom = int(input("Enter between 0-10 snowflakes for the bottom: "))

        draw_blizzard(turtle,size,num_top,num_bottom)

        key = input("Press any key to exit")
        world.destroy()

    else:
        print("Sorry you don't want to play!")

main()