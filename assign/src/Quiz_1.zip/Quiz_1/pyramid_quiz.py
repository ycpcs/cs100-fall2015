__author__ = 'djhake2'
# Load TurtleWorld functions
from TurtleWorld import *
from math import *


# Function to have turtle 't' draw a square of size 'x' CCW
# DO NOT MODIFY
def square(t,x):
    pd(t)
    i = 4
    while i > 0:
        fd(t,x)
        lt(t,90)
        i = i - 1
    pu(t)


# Function to have turtle 't' draw a row of 'numBlocks' blocks (squares) of size 'blockSize'
# DO NOT MODIFY
def row(t, numBlocks, blockSize):
    i = numBlocks                   # initialize i to count down from numBlocks
    while i > 0:                    # draw blocks while i > 0
        square(t, blockSize)        # draw block of size blockSize
        fd(t,blockSize)             # move forward to next block
        i = i - 1                   # count down # of blocks to draw
    bk(t, numBlocks * blockSize)    # back up to original cursor position


# PROBLEM 1
# Function to have turtle 't' draw a centered pyramid of 'height' rows using blocks (squares) of fixed size (20)
#   Note: the height determines the number of blocks in the base row
def centered_pyramid_fixed_block_size(t, height):
    # TODO: Add code to reposition the cursor to draw a centered pyramid

    i = height
    while i > 0:
        # Do not modify code inside the loop
        row(t,i,20)     # draw row with 'i' blocks in it, of size 20
        lt(t,90)        # preparing to position cursor to start of next row
        fd(t, 20)       # moving up one block size (20) for next row
        rt(t,90)        # restoring cursor orientation to face right
        fd(t,20/2)      # move forward half the size of a block
        i = i - 1       # count down # of rows to draw

    # TODO: Modify to reposition the cursor back to the center of the screen (its original position)
    rt(t,90)            # turn cursor to face down
    fd(t,height*20)     # move down to bottom of base row (# of rows * 20)
    lt(t,90)            # restoring cursor orientation to face right
    bk(t,height/2 * 20) # move back to original cursor position


# PROBLEM 2
# Function to have turtle 't' draw an upside down pyramid of 'height' rows using blocks (squares) of fixed size (20)
#   Note: the height determines the number of blocks in the base row
def upsidedown_pyramid_fixed_block_size(t, height):
    i = height
    while i > 0:
        # TODO: Modify code so that the pyramid is drawn upside down, with the TOP of the base row starting at the
        #       cursor, and the pyramid "hanging down" to the right from there
        row(t,i,20)     # draw row with 'i' blocks in it, of size 20
        lt(t,90)        # preparing to position cursor to start of next row
        fd(t, 20)       # moving up one block size (20) for next row
        rt(t,90)        # restoring cursor orientation to face right
        fd(t,20/2)      # move forward half the size of a block
        i = i - 1       # count down # of rows to draw

    # TODO: Modify code to reposition cursor back to its original position (upper left corner of upside down pyramid)
    rt(t,90)            # turn cursor to face down
    fd(t,height*20)     # move down to bottom of base row (# of rows * 20)
    lt(t,90)            # restoring cursor orientation to face right
    bk(t,height/2 * 20) # move back to original cursor position


def main():
    # Create TurtleWorld object
    world = TurtleWorld()
    # Create Turtle object
    t = Turtle()
    t.delay = 0.001

    # Get height of pyramids
    num = int(input('Enter the height of the pyramids: '))

    # Problem 1: Draw centered pyramid using fixed size blocks with num blocks in the base row
    centered_pyramid_fixed_block_size(t,num)

    # Press enter to continue
    key = input('Press any key to run next test')
    world.clear()

    # Problem 2: Draw upside-down pyramid using fixed size blocks with num blocks in the base row
    upsidedown_pyramid_fixed_block_size(t,num)

    # Press enter to exit
    key = input('Press enter to exit')
    world.destroy()

main()