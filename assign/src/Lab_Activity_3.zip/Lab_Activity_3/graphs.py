__author__ = 'djhake2'
# Load TurtleWorld functions
from TurtleWorld import *
from math import *

bar_width = 4
scale = 0.01

# draw X and Y axes - offset origin for more graph space
def draw_axes(t,x_offset, y_offset):
    # move turtle to origin
    move_turtle_no_draw(t,x_offset, y_offset)
    # draw x-axis in black
    move_turtle_draw(t,1000, y_offset, "black")
    # move turtle to origin
    move_turtle_no_draw(t,x_offset, y_offset)
    # draw y-axis in black
    move_turtle_draw(t,x_offset, 600, "black")

# Function to have turtle 't' draw a vertical bar CCW of a fixed width (bar_width) and with height (height * scale)
def draw_bar(t,height):
    pd(t)
    for i in range (2):
        fd(t,bar_width)
        lt(t,90)
        fd(t,height)
        lt(t,90)
    pu(t)
    fd(t,bar_width)


# move turtle to new coordinates
# does not change pen status (up/down)
# does not change pen color
# if pen is already down, draws a line using current color
# if pen is already up, does not draw
def move_turtle(t,x,y):

    # get the current turtle coordinates (x0,y0)
    # TODO: use the t.get_x() and t.get_y() functions to get the current coordinates of the turtle

    # calculate distance to new location (x,y) from current location (x0,, y0)
    # Pythagorean theorem
    # TODO: find the distance to the new coordinates

    # get the current turtle heading (heading0)
    # TODO: use t.get_heading() to get the current heading of the turtle

    # calculate the new turtle heading, based on difference in coordinates
    # recall that arctangent returns the angle for a given tangent value
    # and that tangent = rise / run
    # use Python atan2(x,y) function, which returns the new absolute heading in radians (+ pi to -pi)
    # you'll need to convert heading from radians to degrees (try Google)
    # TODO: calculate the new heading for the turtle using the atan2(x,y) function

    # set the new turtle heading, relative to the current heading
    # use left turn (lt), which is in the positive direction
    # TODO: determine how far left to turn in order to achieve the new heading


    # move the turtle to the new coordinates
    # TODO: move the turtle to the new coordinates



# move turtle to new coordinates without drawing
# TODO: call move_turtle from within this function, making sure not to draw while the turtle moves
def move_turtle_no_draw(t,x,y):




# move turtle to new coordinates while drawing with "color"
# TODO: call move_turtle from within this function, making sure to draw while the turtle moves
def move_turtle_draw(t, x, y, color):




def main():
    # Create TurtleWorld object
    world = TurtleWorld()

    # Create Turtle objects
    t0 = Turtle()   # linear graph axes
    t1 = Turtle()   # linear bar graph
    t2 = Turtle()   # linear curve
    t3 = Turtle()   # x^2 bar graph
    t4 = Turtle()   # x^2 curve
    t5 = Turtle()   # x^2 derivative curve
    t6 = Turtle()   # x^2 integral curve
    t7 = Turtle()   # x^2 graph axes
    t8 = Turtle()   # unused

    # set draw rates for each turtle
    t0.delay = 0.01
    t1.delay = 0.01
    t2.delay = 0.01
    t3.delay = 0.01
    t4.delay = 0.01
    t5.delay = 0.01
    t6.delay = 0.01
    t7.delay = 0.01
    t8.delay = 0.01

    # set the graph origin coordinates
    x_origin = -190
    y_origin = -600

    # get number of values to use for graph
    num = int(input('Enter the # of values to graph: '))
    world.clear()

    # Draw the X and Y axes
    draw_axes(t0,x_origin, y_origin)

    # position t1 into position at origin, assign colors
    pu(t1)
    lt(t1,90)
    fd(t1,y_origin)
    rt(t1,90)
    fd(t1,x_origin)
    t1.set_color("blue")
    t1.set_pen_color("blue")

   # position t2 at origin, assign color
    move_turtle_no_draw(t2,x_origin, y_origin)
    t2.set_color("red")

    # Draw a linear bar graph for the specified number of values
    for i in range(num):
        draw_bar(t1,i)
        move_turtle_draw(t2,i*bar_width + x_origin,i+y_origin,"red")

        # print the value
        print('i: ', i)

    key = input('Press any key to draw a graph using squared values')
    world.clear()

    # position t3 into position at origin, assign colors
    pu(t3)
    lt(t3,90)
    fd(t3,y_origin)
    rt(t3,90)
    fd(t3,x_origin)
    t3.set_color("blue")
    t3.set_pen_color("blue")

    # position t4 at origin, assign color
    move_turtle_no_draw(t4,x_origin, y_origin)
    t4.set_color("red")

    # position t5 at origin, assign color
    move_turtle_no_draw(t5,x_origin, y_origin)
    t5.set_color("green")

    # position t6 at origin, assign color
    move_turtle_no_draw(t6,x_origin, y_origin)
    t6.set_color("violet")

    # Draw the X and Y axes
    draw_axes(t7,x_origin, y_origin)

    # initialize previous value of i^2 for slope calculation
    # TODO: use the variable name 'slope'

    # initialize integral sum
    # TODO: use the variable name 'sum'


    # draw the combination bar graph, curve, derivative, and integral
    # TODO: fill in the code for the TODO's below, and then uncomment the
    #       two move_turtle_draw lines, and then print line - they do not need changed
    for i in range (num):
        # calculate the squared value
        i2 = i*i

        # draw bar graph in blue
        draw_bar(t3,i2*scale)

        # draw i^2 curve in red
        move_turtle_draw(t4,i*bar_width + x_origin,(i2 * scale) + y_origin,"red")

        # calculate slope
        # TODO: calculate the slope for this point and the previous point

        # draw derivative curve in green (scaling by 20 to show curve relative to x^2 value)
#        move_turtle_draw(t5,i*bar_width + x_origin,(slope * scale*20) + y_origin, "green")

        # save current i^2 value for next slope
        # TODO: save the current i^2 value for next time

        # calculate sum
        # TODO: calculate the sum of the i^2 values

        # draw integral curve in violet
#       move_turtle_draw(t6,i*bar_width + x_origin,(sum * scale) + y_origin, "violet")

        # print the values being graphed
#        print('i: ', i, ' i^2: ', i2, ' derivative: ', slope, ' integral: ', sum)

    key = input('Press any key to exit')
    world.destroy()

main()